/* cursex.c */
#include <curses.h>

void use_my_colours() {
	use_default_colors();
	init_pair(0, -1, -1);
	init_pair(1, 1, -1);
	init_pair(2, 2, -1);
	init_pair(3, 3, -1);
	init_pair(4, 4, -1);
	init_pair(5, 5, -1);
	init_pair(6, 6, -1);
	init_pair(7, -1, -1);
}

