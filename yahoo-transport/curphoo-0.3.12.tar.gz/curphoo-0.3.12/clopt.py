# clopt.py
# Copyright 2002 Alex Mercader <alex.mercader@iinet.net.au>
#
# This file is part of Curphoo.
#
# Curphoo is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# Curphoo is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with Curphoo; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#
# $Id: clopt.py,v 1.1 2003/09/25 17:31:45 mkennedy Exp $
#
# $Log: clopt.py,v $
# Revision 1.1  2003/09/25 17:31:45  mkennedy
# intial import
#
# Revision 1.2  2002/05/04 23:06:52  hacker
# added a more verbose curphoo -h
# took out support for --log-file option
#
# Revision 1.1  2002/05/01 08:39:22  hacker
# Initial revision
#
#
##

import sys, getopt

def usage():
	print """
Curphoo 0.3.7
Usage:
	curphoo [-u<username>] [-r<chat room>] [-l]

Options:
	-u    specify which yahoo id to use
	-r    specify which chat room to go to
	-l    log chat and save to $HOME/.curphoo/log
	--norc	specify that you don't want your curphoorc loaded

Example:
	curphoo -uthe_cpu_fan -r"Linux, FreeBSD, Solaris:1"

"""

def do():
	username = ''
	room = ''
	server = ''
	log=0
	norc=0
	try:
		opts = getopt.getopt(sys.argv[1:], "u:r:s:lh", ['norc'])[0]

		if len(opts) == 1 and opts[0][0] == '-h':
			usage()
			sys.exit(0)
		else:
			for o, a in opts:
				if o == '-u':
					username = a
				elif o == '-r':
					room = a
				elif o == '-s':
					server = a
				elif o == '-l':
					log = 1
				elif o == '--norc':
					norc = 1
		if norc:
			switch = [e[0] for e in opts]
			# unless -u is specified clear username
			if '-u' not in switch:
				username = ""
			# unless -r is specified clear room
			if '-r' not in switch:
				room = ""
	except getopt.GetoptError:
		usage()
		sys.exit(1)
	return (username, room, server, log, norc)

