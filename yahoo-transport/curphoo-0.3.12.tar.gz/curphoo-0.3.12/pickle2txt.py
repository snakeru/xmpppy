#!/usr/bin/python

# convert object serialized file (ignorex) to plain text file (ignore.txt)

import pickle, string

ignores = []
try:
	fin = open("ignorex", "r")
	ignores = pickle.load(fin)
	fin.close()
except:
	pass

s = string.join(ignores, "\n")
try:
	fout = open("ignore", "w")
	fout.write(s)
	fout.close()
except:
	pass

